<?php
file_put_contents('channel_v3.json', 'https://packagecontrol.io/channel_v3.json');
echo "下载完成";